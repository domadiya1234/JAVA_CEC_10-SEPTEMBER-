package abc;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class edit
 */
@WebServlet("/edit")
public class edit extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public edit() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id= request.getParameter("id");
		String name= request.getParameter("name");
		String author= request.getParameter("author");
		PrintWriter out = response.getWriter();
		out.println("<html><body>");
		out.println("<form action='edit'method='post'>");
		out.println("id <input type='hidden' name='id' value='"+id+"'/><br><br>");
		out.println("name <input type='text' name='name' value='"+name+"'/><br><br>");
		out.println("Author <input type='text' name='author' value='"+author+"'/><br><br>");
		out.println("<input type='submit'/>");
		out.println("<br>");
		out.println("</body></html>");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		out.println("<html><body>");
		out.println("<form action='edit'>");
		out.println("</body></html>");
		try {
			
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://128.66.203.247/imsc7it118","imsc7it118","sumo@123");
				String id= request.getParameter("id");
				String name= request.getParameter("name");
				String author= request.getParameter("author");
				
				PreparedStatement pst = con.prepareStatement(" UPDATE book SET name=?,author=? WHERE id=?");
				pst.setString(1, name);
				pst.setString(2, author);
				pst.setNString(3, id);
				pst.executeUpdate();
				
				out.println("edited...<br>");
				out.println("<a href='display'>Back To Display</a>");
			}
		catch(Exception e) 
		{
			System.out.println(e);
		}
	}

}
